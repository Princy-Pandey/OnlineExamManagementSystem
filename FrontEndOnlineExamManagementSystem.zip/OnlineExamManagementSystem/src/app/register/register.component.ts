import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { User } from '../_models/user';
import { FormGroup } from '@angular/forms';
import { AuthenticateService } from '../_services/authenticate.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  /*********************************************************************
   *  Instance of User for manupulation
   *********************************************************************/
  user: User = new User();
  msg: string;
  errorMsg: string;

  form: FormGroup = new FormGroup({});


  constructor(private userService: UserService, private authService: AuthenticateService, private router: Router) { }


  ngOnInit(): void { }


  get f() { return this.form.controls; }

  /*************************************************************************
   * Method:        addRegistration
   * params:
   * return:        
   * Description:   This method is sending new user details to the backend. 
   *             
   * Created Date:  02 May 2020
   * Author:        Maneesh Kumar
   *************************************************************************/
  addRegistration() {
    this
      .userService
      .addRegisteration(this.user)
      .subscribe((data) => {
        console.log("data", data);
        this.msg = data;
        this.errorMsg = undefined;
        this.user = new User()
        this.router.navigateByUrl("/login")
      },
        error => {
          this.errorMsg = JSON.parse(error.error).message;
          console.log(error.error);
          this.msg = undefined
          this.router.navigateByUrl("/register")
        });
  }


  /*****************************************************************************
   * Method:        openLoginView
   * params:
   * return:        
   * Description:   This method is used to transist from register component
   *                to the login component by verifing whether the localStorage
   *                have token stored in it.
   *             
   * Created Date:  02 May 2020
   * Author:        Maneesh Kumar
   *****************************************************************************/
  OpenLoginView() {
    //this.router.navigateByUrl('/login');
    if (this.authService.isLoggedIn() == true) {
      this.router.navigateByUrl('/userpage');
    }
    else {
      this.router.navigateByUrl('/login');
    }
  }


}
