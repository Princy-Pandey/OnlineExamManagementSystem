import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User, Admin } from '../_models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService 
{
  public userMail: string;
  public userPassword: string;
  public secretWord: string;
  userMailPass: string;

  
  constructor(private http:HttpClient) { }


  /*********************************************************************
   * Method:                deleteUser
   * params:                user
   * return:                
   * Description:           this method is delete the user details.
   ************************************************************************/
  deleteUser(user: User) 
  {
    return this.http.delete<User>("http://localhost:8082/deleteuser" + "/"+ user.userId);
  }

  /*********************************************************************
   * Method:               updatePassword
   * params:               user
   * return:               Observable
   * Description:          this method is updating password.
   ************************************************************************/
  public updatePassword(user: User):Observable<any>
  {
    console.log("updated");
         let usermail= user.userMail;
         return this.http.put<User>("http://localhost:8082/updatepassword/"+usermail, user);
  }


  /*********************************************************************
   * Method:        addRegistration
   * params:        user
   * return:        Observable
   * Description:   this method is adding new user.
   ************************************************************************/
  addRegisteration(user:User):Observable<any>
  {
    return this.http.post("http://localhost:8082/registration",user,{responseType:'text'})
  }
  
  
  /*********************************************************************
   * Method:          addAdmin
   * params:          admin
   * return:          Observable
   * Description:     this method is adding new admins in user.
   ************************************************************************/
  addAdmin(admin: Admin):Observable<any>
  {
    return this.http.post("http://localhost:8082/addadmin",admin,{responseType:'text'})
  }

  /*********************************************************************
   * Method:                  viewUsers
   * params: 
   * return:                  Observable
   * Description:             this method is getting all the users.
   ************************************************************************/
  viewUsers():Observable<any>
  {
    return this.http.get("http://localhost:8082/viewusers");
  }

  /*********************************************************************
   * Method:               findByMail
   * params:               userMail
   * return:               user
   * Description:          this method is finding the userMail is user.
   ************************************************************************/
  findByMail(userMail: string):Observable<any>
  {
    const httpOptions = { headers:new HttpHeaders({'Content-type':'application/json'}) };
    return this.http.get("http://localhost:8082/viewuserbymail/" + userMail,httpOptions);
  }

  /*********************************************************************
   * Method:            getLogin
   * params:            userMail, userPassword
   * return:            
   * Description:       this method is getting user details for login.
   ************************************************************************/
  getLogin(userMail: string, userPassword: string)
  { 
    this.userPassword = userPassword;
    this.userMail = userMail;
    return this.http.get(
      "http://localhost:8082/login/" + userMail + "/" + userPassword);
  }

  /************************************************************************
   * Method:                getUserVerify
   * params:                userMail, secretWord
   * return:                
   * Description:           this method is getting user details to verify to
   *                        change password later.
   ************************************************************************/
  getUserVerify(userMail: string, secretWord: string)
  { 
    this.userMail = userMail;
    this.secretWord = secretWord;
    return this.http.get(
      "http://localhost:8082/verifyuser/" + userMail + "/" + secretWord);
  }
}
