import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticateService } from './authenticate.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {
  
  constructor(private authService: AuthenticateService, private router: Router){}

  /*********************************************************************
   * Method:                canActivate
   * params:                
   * return:                true/false
   * Description:           this method is used to direct to pages on which
   *                        canActivate is put in the app-routing.
   *                        If the isLoggedIn func passes false canActivate
   *                        will stop the page from opening. If the value
   *                        comes true, canActivate will allow the user to
   *                        navigate to that page.
   ************************************************************************/
  canActivate(next: ActivatedRouteSnapshot,state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean 
    {
      if(!this.authService.isLoggedIn())
      {
        this.router.navigateByUrl('/login');
        return false;
      }
      return true;      
  }
}
