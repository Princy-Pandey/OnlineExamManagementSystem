import { Injectable } from '@angular/core';
import { User } from '../_models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor() { }
  
  /*********************************************************************
   * Method:                login
   * params:                userInfo
   * return:                
   * Description:           this method is storing the user details coming
   *                        from the login page as a token.
   ************************************************************************/
  public login(userInfo: User)
  {
    localStorage.setItem('ACCESS_TOKEN', JSON.stringify(userInfo));
  }

  /*********************************************************************
   * Method:                isLoggedIn
   * params:                
   * return:                true/false
   * Description:           this method is whether any token is stored in
   *                        localStorage or not.
   ************************************************************************/
  public isLoggedIn(): boolean
  {
    const token = localStorage.getItem('ACCESS_TOKEN');
    if(token == null) return false;
    return true;
  }

  /*********************************************************************
   * Method:                logout
   * params:                
   * return:                
   * Description:           this method is deleting the token stored in
   *                        the local Storage.
   ************************************************************************/
  public logout()
  {
    localStorage.removeItem('ACCESS_TOKEN');
  }
}
