import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticateService } from '../_services/authenticate.service';
import { UserService } from '../_services/user.service';

export class User {
  userId: String;
  userRole = "user";
  userName: string;
  userMail: string;
  userPassword: string;
  userContact: number;
  userGender: string;
  userAge: number;
  secretWord: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User
  public userMail: string;
  public userPassword: string;
  info: string;
  errorInfo: string;

  loginForm: FormGroup;
  invalidLogin = false;
  submitted: boolean = false;
  constructor(private userService: UserService, private authService: AuthenticateService,
    private router: Router, private formBuilder: FormBuilder) { }

/**********************************************************************************
   * Method:        ngOnInit is life cycle hook called by angular at first
   * params:
   * return:
   * Description:   ngOnInit is getting the values of the userMail and userPassword
   *                entered by the user and passing the values to the userLogin().
   *********************************************************************************/
  ngOnInit(): void {
   this.loginForm = this.formBuilder.group({
      userMail: ['', Validators.required],
      userPassword: ['', Validators.required]
    });
  }

  /*****************************************************************************
  * Method:        userLogin
  * params:
  * return:        
  * Description:   This method is getting the userMail and userPassword 
  *                from NgOnInIt and sending those values to the server 
  *                end to check whether the details exist or not and 
  *                returning integer type
  *                as 1 -> User's data
  *                as 2-> Admin's data
  *                as 0-> Data not present.(triggers inValidLogin div in html.)
  *                Also, it is storing a token of user's detail in localStroage
  *                for further checking of the user's logged in status.
  *******************************************************************************/
  userLogin() {
    this.submitted = true;
    if (this.loginForm.valid) {
      console.log(this.loginForm.value)
      this.authService.login(this.loginForm.value);
      this.userMail = this.loginForm.controls.userMail.value;
      this.userPassword = this.loginForm.controls.userPassword.value;
      this.userService
        .getLogin(this.userMail, this.userPassword)
        .subscribe((data) => {
          if (data === 1) {
            this.router.navigate(["/userpage"]);
          }
          else if (data === 2) {
            this.router.navigate(["/adminpage"]);
          }
          else {
            this.invalidLogin = true;
          }
        },
          error => {
            this.info = undefined;
            this.errorInfo = error.error;
            console.log(this.errorInfo);
            alert(this.errorInfo);
          });
    }
    else {
      return;
    }
  };

/**************************************************************************
   * Method:        forgetPassword
   * params:
   * return:
   * Description:   Routes the user from login page to verification page
   *                if the user has forgot his password and he/she wants 
   *                update the password with the new one. 
   *              
   * Created Date:  02 May 2020
   * Author:        Maneesh Kumar
   ************************************************************************/
  forgetPassword() {
    this.router.navigateByUrl('/forgetPassword');
  }
}
