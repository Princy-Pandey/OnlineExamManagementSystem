import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { User, Admin } from '../_models/user';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit 
{
  /*************************************************************************
  * creating Admin instance for every time manupulate the data
  *************************************************************************/
  admin: Admin = new Admin();
  msg: string;
  errorMsg: string;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {}

  
/*******************************************************************************
   * Method:        addAdmin
   * params:
   * return:
   * Description:   This method is used to add new admins into the user table.
   *****************************************************************************/
  addAdmin()
  {
    this
    .userService
    .addAdmin(this.admin)
    .subscribe((data)=>
    {
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.admin = new Admin()
      this.router.navigateByUrl('/adminpage');
    },
    error=>
    { this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined
      this.router.navigateByUrl('/addadmin');
    });
  
    
  }
}
